package com.desrumaux.androidtoolbox.model

class Contact {
    var contactName: String = ""
}